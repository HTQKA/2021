```
潘吉鑫	生产管理	panjixin	
卢郑	生产管理	luzheng	
罗海平	生产管理	luohaiping	
陈媛媛	生产管理	chenyuanyuan	
周智童	生产管理	zhouzhitong	
陈栓	生产管理	chenshuan	1508
沈新康	生产管理	shenxinkang	
清远生产管理总账户	生产管理	qyshengchan	
舒莉莉	生产管理	shulili	
周彬	生产管理	zhoubin	
舒迪	生产管理	shudi	
曾伟浩	生产管理	zengweihao	
周伟	生产管理	zhouwei	
陈勇	生产管理	chenyong	
罗亚明	生产管理	luoyaming	
凌宇	生产管理	lingyu	1508
潘建明	生产管理	panjianming	
蔡勇	生产管理	caiyong	
潘强	生产管理	panqiang	
赵奇	生产管理	zhaoqi	
俞童慷	生产管理	yutongkuang	
```

